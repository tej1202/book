<?php

	// Custom post type for Portfolio
function book_post() {
  $labels = array(
    'name'               => _x( 'Book', 'post type general name' ),
    'singular_name'      => _x( 'Book', 'post type singular name' ),
    'add_new'            => _x( 'Add New', 'search_book' ),
    'add_new_item'       => __( 'Add New Book' ),
    'edit_item'          => __( 'Edit Book' ),
    'new_item'           => __( 'New Book' ),
    'all_items'          => __( 'All Book' ),
    'view_item'          => __( 'View Book' ),
    'search_items'       => __( 'Search Book' ),
    'not_found'          => __( 'No Service found' ),
    'not_found_in_trash' => __( 'No Service found in the Trash' ), 
    'parent_item_colon'  => '',
    'menu_name'          => 'Book'
  );
  $args = array(
    'labels'        => $labels,
    'public'        => true,
    'menu_position' => 5,
    'menu_icon'		=> 'dashicons-images-alt',
    'show_in_rest' => true,
    'show_admin_column' => true,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
    'has_archive'   => true,

  );
  register_post_type( 'book', $args );
  register_taxonomy(
        'author',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'book',             // post type name
        array(
            'hierarchical' => true,
            'label' => 'Author category', // display name
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array(
                'slug' => 'author',    // This controls the base slug that will display before each term
                'with_front' => true  // Don't display the category base before
            )
        )
    );

  	register_taxonomy(
        'publisher',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'book',             // post type name
        array(
            'hierarchical' => true,
            'label' => 'Publisher category', // display name
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array(
                'slug' => 'publisher',    // This controls the base slug that will display before each term
                'with_front' => true  // Don't display the category base before
            )
        )
    );

}
add_action( 'init', 'book_post' );


?>