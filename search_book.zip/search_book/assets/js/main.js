(function ($) {
  "use strict";

  // Preloader (if the #preloader div exists)
  $(window).on('load', function () {
    if ($('#preloader').length) {
      $('#preloader').delay(100).fadeOut('slow', function () {
        $(this).remove();
      });
    }
  });

  // Back to top button
  $(window).scroll(function() {
    if ($(this).scrollTop() > 100) {
      $('.back-to-top').fadeIn('slow');
    } else {
      $('.back-to-top').fadeOut('slow');
    }
  });
  $('.back-to-top').click(function(){
    $('html, body').animate({scrollTop : 0},1500, 'easeInOutExpo');
    return false;
  });

  // Initiate the wowjs animation library
  new WOW().init();

  // Header scroll class
  
  // Smooth scroll for the navigation and links with .scrollto classes
  $('.main-nav a, .mobile-nav a, .scrollto').on('click', function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      if (target.length) {
        var top_space = 0;

        if ($('#header').length) {
          top_space = $('#header').outerHeight();

          if (! $('#header').hasClass('header-scrolled')) {
            top_space = top_space - 40;
          }
        }

        $('html, body').animate({
          scrollTop: target.offset().top - top_space
        }, 1500, 'easeInOutExpo');

        if ($(this).parents('.main-nav, .mobile-nav').length) {
          $('.main-nav .active, .mobile-nav .active').removeClass('active');
          $(this).closest('li').addClass('active');
        }

        if ($('body').hasClass('mobile-nav-active')) {
          $('body').removeClass('mobile-nav-active');
          $('.mobile-nav-toggle i').toggleClass('fa-times fa-bars');
          $('.mobile-nav-overly').fadeOut();
        }
        return false;
      }
    }
  });

  // Navigation active state on scroll
  var nav_sections = $('section');
  var main_nav = $('.main-nav, .mobile-nav');
  var main_nav_height = $('#header').outerHeight();

  $(window).on('scroll', function () {
    var cur_pos = $(this).scrollTop();
  
    nav_sections.each(function() {
      var top = $(this).offset().top - main_nav_height,
          bottom = top + $(this).outerHeight();
  
      if (cur_pos >= top && cur_pos <= bottom) {
        main_nav.find('li').removeClass('active');
        main_nav.find('a[href="#'+$(this).attr('id')+'"]').parent('li').addClass('active');
      }
    });
  });

  // jQuery counterUp (used in Whu Us section)
  $('[data-toggle="counter-up"]').counterUp({
    delay: 10,
    time: 1000
  });

  // Porfolio isotope and filter
  $(window).on('load', function () {
    var portfolioIsotope = $('.portfolio-container').isotope({
      itemSelector: '.portfolio-item'
    });
    $('#portfolio-flters li').on( 'click', function() {
      $("#portfolio-flters li").removeClass('filter-active');
      $(this).addClass('filter-active');
  
      portfolioIsotope.isotope({ filter: $(this).data('filter') });
    });
  });

  // Testimonials carousel (uses the Owl Carousel library)
  $(".testimonials-carousel").owlCarousel({
    autoplay: true,
    dots: true,
    loop: true,
    items: 1,
    // nav: true,
    //responsive: { 0: { items: 2 }, 768: { items: 4 }, 900: { items: 6 }}
  });

  // Clients carousel (uses the Owl Carousel library)
  $(".clients-carousel").owlCarousel({
    autoplay: true,
    dots: true,
    loop: true,
    responsive: { 0: { items: 2 }, 768: { items: 4 }, 900: { items: 6 }
    }
  });

})(jQuery);


$(document).ready(function(){
  $('.carousel').slick({
  slidesToShow: 3,
  dots:true,
  centerMode: true,
  });
});


// slider js
$(document).ready(function(){
  
  $(".Modern-Slider").slick({
    autoplay:true,
    autoplaySpeed:10000,
    speed:600,
    slidesToShow:1,
    slidesToScroll:1,
    pauseOnHover:false,
    dots:true,
    pauseOnDotsHover:true,
    cssEase:'linear',
   // fade:true,
    draggable:false,
    prevArrow:'<button class="PrevArrow"></button>',
    nextArrow:'<button class="NextArrow"></button>', 
  });
  
})


// jQuery(document).ready(function($) {

//  console.log(sliderContentArray.in_content);

// });


// $('#portfolio-flters li').on( 'click', function() {
//   var click_cat = $(this).attr('data-filter');
//   click_cat = click_cat.substring(1);
//   $(".cat-portfolio-flters li").hide();
//   $(".cat-portfolio-flters ."+click_cat).show();
//     });

// $(window).on('load', function () {
//         $("#portfolio-flters:first-child li:first-child").trigger('click');
//     $(".cat-portfolio-flters li").hide();

// });


// $('#portfolio-flters li').on( 'click', function() {
//   var click_cat = $(this).attr('data-filter');
//   click_cat = click_cat.substring(1);
//   $(".cat-portfolio-flters li").hide();
//   $(".cat-portfolio-flters ."+click_cat).show();
  
//     });

// $(function() {
//   $('.portfolio-wrap').matchHeight();
// });


// $('#portfolio-flters li').on('click', function() {
//     var filterClass = jQuery(this).attr('data-filter');
//     var filterClass = "."+filterClass;

  $('.product li').on( 'click', function() {
  var click_cat = jQuery(this).attr('data-filter');
  click_cat = click_cat.substring(1);
  console.log(click_cat);
  $(".cat-portfolio-flters li").hide();
  $(".cat-portfolio-flters"+click_cat).show();
});

// var typed = new Typed('.type', {
//   strings: [sliderContentArray.in_content],
//   typeSpeed: 60,
//   backSpeed: 60,
//   loop: true
// });


// $("img").unveil(200, function() {
//   $(this).load(function() {
//     this.style.opacity = 1;
//   });
// });

// $(function() {
//         $('.lazy').lazy({
//             placeholder: "data:image/gif;base64,R0lGODlhEALAPQAPzl5uLr9Nrl8e7..."
//         });
// });

// echo.init({
//         callback: function (element, op) {
//             console.log(element, 'has been', op + 'ed')
//             $(".filter-active").trigger('click');
//         }
//     });

// var intervalId = setInterval(someFunction, 1000),
// clearInterval(intervalId);

// setTimeout(function(){ $(".filter-active").trigger('click'); }, 3000); 


// $('.responsive').slick({
//   arrow: true,
//   dots: true,
//   infinite: false,
//   speed: 300,
//   slidesToShow: 4,
//   slidesToScroll: 4,
//   autoplay: true,
//   autoplaySpeed: 2000,
//   responsive: [
//     {
//       breakpoint: 1024,
//       settings: {
//         slidesToShow: 3,
//         slidesToScroll: 3,
//         infinite: true,
//         dots: true
//       }
//     },
//     {
//       breakpoint: 600,
//       settings: {
//         slidesToShow: 2,
//         slidesToScroll: 2
//       }
//     },
//     {
//       breakpoint: 480,
//       settings: {
//         slidesToShow: 1,
//         slidesToScroll: 1
//       }
//     }
//     // You can unslick at a given breakpoint now by adding:
//     // settings: "unslick"
//     // instead of a settings object
//   ]
// });

// // $('#portfolio-flters li').on('click', function() {
// //     var filterClass = jQuery(this).attr('data-filter');
// //     $('.slick').slick('slickUnfilter');
// //     $('.slick').slick('slickFilter', filterClass);
// //   });









  $(function(){
  $('.slick').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    infinite: true,
  });
  
  // When the filter values are changed, 
  // apply the filter to slick.
  $('#portfolio-flters li').on('click', function() {
    var filterClass = jQuery(this).attr('data-filter');
    var filterClass = "."+filterClass;
    // console.log(filterClass);
    //return false;
    //var filterClass = getFilterValue();
    // $('.filter-class').text(filterClass);
    $('.slick').slick('slickUnfilter');
    $('.slick').slick('slickFilter', filterClass);
  });

  $('#cat-portfolio-flters li').on('click', function() {
    var subCat = jQuery(this).attr('data-filter');
    var subCat = "."+subCat;
     console.log(subCat);
    //return false;
    //var filterClass = getFilterValue();
    // $('.filter-class').text(filterClass);
    $('.slick').slick('slickUnfilter');
    $('.slick').slick('slickFilter', subCat);
  });

  // $('#cat-portfolio-flters li').on('click', function() {
  //   var subCat = jQuery(this).attr('data-filter');
  //   var subCat = "."+subCat;
  //   console.log(subCat);
  //   //return false;
  //   //var filterClass = getFilterValue();
  //   // $('.filter-class').text(filterClass);
  //   $('.slick').slick('slickUnfilter');
  //   $('.slick').slick('slickFilter', subCat);
  // });


  // $('#cat-portfolio-flters li').on('click', function() {
  //   var subCat = jQuery(this).attr('data-filter');
  //   var subCat = "."+subCat;
  //   // console.log(filterClass);
  //   //return false;
  //   //var filterClass = getFilterValue();
  //   // $('.filter-class').text(filterClass);
  //   $('.slick').slick('slickUnfilter');
  //   $('.slick').slick('slickFilter', subCat);
  // });


  
  });
  



var dropdown = document.getElementById("meta-select");
    function onCatChange() {
        if ( dropdown.options[dropdown.selectedIndex].value != -1 ) {
            location.href = "<?php echo home_url();?>/category/"+dropdown.options[dropdown.selectedIndex].value+"/";
        }
    }
    dropdown.onchange = onCatChange;