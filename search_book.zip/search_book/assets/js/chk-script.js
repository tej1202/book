jQuery(document).ready(function($) {




    $('#acf-form input[type=checkbox]').click(function(){
        // $('input[type=checkbox]').each(function(){
    var choices = {};

        //     // console.log(this);

        // });
        $('input[type=checkbox]:checked').each(function() {
                // console.log(this);
                if (!choices.hasOwnProperty(this.name)) 

                    choices[this.name] = [this.value];
                else 
                    choices[this.name].push(this.value);


            });

         
     // console.log(choices);
    // This does the ajax request
    $.ajax({
        url: example_ajax_obj.ajaxurl,
        type :'POST',
        data: {
            'action': 'example_ajax_request',
            'select' : choices,
            'nonce' : example_ajax_obj.nonce
        },
        success:function(data) {
            // $('.response').empty();
            $('.response').html(data);
            // $('.response').prop("checked", false);
            // This outputs the result of the ajax request
            // alert(data);
        },
        error: function(errorThrown){
            console.log(errorThrown);
        }
    });  
    });      
});

 // jQuery(document).ready(function($){

 //        $('#acf-form input[type=checkbox]').click(function(){

 //            // declaring an array
 //            var choices = {};


 //            // $('.contents').remove();
 //            // $('.filter-output').empty()

 //            $('input[type=checkbox]:checked').each(function() {
 //                if (!choices.hasOwnProperty(this.name)) 
 //                    choices[this.name] = [this.value];
 //                else 
 //                    choices[this.name].push(this.value);
 //            });


 //            // console.log(choices);
 //            $.ajax({

 //                url: example_ajax_obj.ajaxurl,,
 //                type :'POST',
 //                data : {
 //                    'action' : 'example_ajax_request', // the php name function
 //                    'choices' : choices,
 //                },
 //                success: function (result) {
 //                    // $('.response').append(result);
 //                    // just for test - success (you can remove it later)
 //                    console.log(result);
 //                    //console.log(choices);
 //                },
 //                error: function(err){
 //                    // just for test - error (you can remove it later)
 //                    console.log(err);
 //                    console.log(choices);
 //                }
 //            });
 //        })
 //    });

    // jQuery(document).ready(function($){

    //     $('#acf-form input[type=checkbox]').click(function(){


    //         // declaring an array
    //         var choices = {};

    //         // $('.contents').remove();
    //         // $('.filter-output').empty()

    //         $('input[type=checkbox]:checked').each(function() {
    //             if (!choices.hasOwnProperty(this.name)) 
    //                 choices[this.name] = [this.value];
    //             else 
    //                 choices[this.name].push(this.value);
    //         });


    //          console.log(choices);


    //         // var a = [];
    //         //  $('input[type=checkbox]:checked').each(function() {
    //         //     a.push(this.value);
    //         // });

    //          $.ajax({
    //             url: myajax.ajaxurl,
    //             type :'POST',
    //             data : {
    //                 'action' : 'call_post', // the php name function
    //                 'choices' : choices,
    //             },
    //             success: function (result) {
    //                 $('.about-content').append(result);
    //                 // just for test - success (you can remove it later)
    //                 //console.log(result);
    //                 //console.log(choices);
    //             },
    //             error: function(err){
    //                 // just for test - error (you can remove it later)
    //                 console.log(err);
    //                 console.log(choices);
    //             }
    //          });

    //          // return a;
  
    // });
    // });