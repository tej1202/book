  <?php 
    if (have_rows('image_slider')) {
      ?>
      <script>
        jQuery(document).ready(function($) {

            var typed = new Typed('.type', {
              strings: [

                <?php 

                  $content = array();
                  while (have_rows('image_slider')) {
                  the_row();  
                  $conttent[] = get_sub_field('inner_content');
                }
                echo $conttent;
                ?>

              ],
              typeSpeed: 60,
              backSpeed: 60,
              loop: true
            });
        });
      </script>
    <?php 
  } // end if have_rows
?>