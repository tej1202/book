<?php 

/* Template Name: Home */
// get_header();
?>
<br>
<br>
<br>
<br>
<!-- About section -->
<main id="main">
<section id="about">
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-6">
        <div class="about-content">
          <?php echo get_template_part( 'advanced', 'searchform' );?>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="about-img">
        	
        </div>
      </div>
    </div>
  </div>
</section>
<!-- <div class="response"></div> -->
