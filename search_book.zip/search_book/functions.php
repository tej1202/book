<?php
/**
 * search_book functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package search_book
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'search_book_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function search_book_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on search_book, use a find and replace
		 * to change 'search_book' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'search_book', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Primary', 'search_book' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'search_book_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'search_book_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function search_book_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'search_book_content_width', 640 );
}
add_action( 'after_setup_theme', 'search_book_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function search_book_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'search_book' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'search_book' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'search_book_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function search_book_scripts() {
	

		wp_enqueue_style( 'font-awsome-min', get_template_directory_uri() . '/assets/lib/font-awesome/css/font-awesome.min.css',true );

	wp_enqueue_style( 'animate-min', get_template_directory_uri() . '/assets/lib/animate/animate.min.css',true );
	wp_enqueue_style( 'ionicons-min', get_template_directory_uri() . '/assets/lib/ionicons/css/ionicons.min.css',true );
	wp_enqueue_style( 'owl-carousel-min', get_template_directory_uri() . '/assets/lib/owlcarousel/assets/owl.carousel.min.css',true );
	wp_enqueue_style( 'lightbox-min', get_template_directory_uri() . '/assets/lib/lightbox/css/lightbox.min.css',true );
	
	wp_enqueue_style( 'slick', get_template_directory_uri() . '/assets/css/slick.css',true );

	wp_enqueue_style( 'slick-theme', get_template_directory_uri() . '/assets/css/slick-theme.css',true );
	
	wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css',true );

	wp_enqueue_script( 'jquery-min-js', 'https://code.jquery.com/jquery-3.5.1.min.js', array(), '20151215', true );

	// wp_enqueue_script( 'jquery-min-js', get_template_directory_uri() . '/assets/lib/jquery/jquery.min.js', array(), '20151215', true );
	// wp_enqueue_script( 'jquery-migrate.min.js', get_template_directory_uri() . '/assets/lib/jquery/jquery-migrate.min.js', array(), '20151215', true );
	wp_enqueue_script( 'bootstrap-bundle-min-js', get_template_directory_uri() . '/assets/lib/bootstrap/js/bootstrap.bundle.min.js', array(), '20151215', true );

	wp_enqueue_script( 'easing-min-js', get_template_directory_uri() . '/assets/lib/easing/easing.min.js', array(), '20151215', true );
	wp_enqueue_script( 'mobile-nav-js', get_template_directory_uri() . '/assets/lib/mobile-nav/mobile-nav.js', array(), '20151215', true );
	wp_enqueue_script( 'wow-min-js', get_template_directory_uri() . '/assets/lib/wow/wow.min.js', array(), '20151215', true );
	wp_enqueue_script( 'waypoints-min-js', get_template_directory_uri() . '/assets/lib/waypoints/waypoints.min.js', array(), '20151215', true );

	wp_enqueue_script( 'counterup-min-js', get_template_directory_uri() . '/assets/lib/counterup/counterup.min.js', array(), '20151215', true );
	wp_enqueue_script( 'owl-carousel-min-js', get_template_directory_uri() . '/assets/lib/owlcarousel/owl.carousel.min.js', array(), '20151215', true );
	wp_enqueue_script( 'isotope-pkgd-min-js', get_template_directory_uri() . '/assets/lib/isotope/isotope.pkgd.min.js', array(), '20151215', true );
	wp_enqueue_script( 'lightbox-min-js', get_template_directory_uri() . '/assets/lib/lightbox/js/lightbox.min.js', array(), '20151215', true );
    
    wp_enqueue_script( 'slick-min-js',  'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array(), '20151215', true );

	wp_enqueue_script( 'contactform-js', get_template_directory_uri() . '/assets/contactform/contactform.js', array(), '20151215', true );

	wp_enqueue_script( 'typeds-js', 'https://cdn.jsdelivr.net/npm/typed.js@2.0.11', array(), '20151215', true );
	wp_enqueue_script( 'typed-js', get_template_directory_uri() . '/assets/js/typed.js', array(), '20151215', true );
	// wp_enqueue_script( 'jquery-matchHeight-js', get_template_directory_uri() . '/assets/js/jquery.matchHeight.js', array(), '20151215', true );

		
	// wp_enqueue_script( 'echo-js', get_template_directory_uri() . '/assets/js/echo.min.js', array(), '20151215', true );
	
	// wp_enqueue_script( 'jquery-lazy-min-js', '//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js', array(), '20151215', true );
	
	// wp_enqueue_script( 'jquery-matchHeight', get_template_directory_uri() . '/assets/js/jquery.matchHeight.js', array(), '20151215', true );

	wp_enqueue_script( 'main-js', get_template_directory_uri() . '/assets/js/main.js', array(), '20151215', true );

}
add_action( 'wp_enqueue_scripts', 'search_book_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';


/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/custom_posttype.php';


/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}



function wpse_load_custom_search_template(){
    if( isset($_REQUEST['search']) == 'advanced' ) {
        require('advanced-search-result.php');
        die();
    }
}
add_action('init','wpse_load_custom_search_template');

/**
 * Create Custom Query Vars
 */
//  function add_query_vars_filter( $vars ) {
//     // add custom query vars that will be public
//     // https://codex.wordpress.org/WordPress_Query_Vars
//     $vars[] .= 'book_price';
// 	$vars[] .= 'rating';
// 	$vars[] .= 'author_category_ids';
// 	$vars[] .= 'publisher_category_ids';
//     return $vars;
// }
// add_filter( 'query_vars', 'add_query_vars_filter' );

// /**
//  * Override Movie Archive Query
 
//  */
// function book_archive( $query ) {
//     // only run this query if we're on the movie archive page and not on the admin side
//     if ( $query->is_archive('book') && $query->is_main_query() && !is_admin() ) {

//         // get query vars from url.
//         // https://codex.wordpress.org/Function_Reference/get_query_var#Examples

//         // example.com/movie/?rating=4
//         $rating = get_query_var( 'rating', FALSE );
//         // example.com/movie/?director_id=14
//         $bookprice = get_query_var( 'book_price', FALSE );
//         // example.com/movie/?movie_category_ids[]=6
//         $author = get_query_var( 'author_category_ids', FALSE);

//         $publisher = get_query_var( 'publisher_category_ids', FALSE);

//         // used to conditionally build the meta_query
//         // the meta_query is used for searching against custom fields
//         $meta_query_array = array('relation' => 'AND');

//         // conditionally add arrays to the meta_query based on values in the URL
//         // the `key` is the name of my custom fields
//         $bookprice ? array_push($meta_query_array, array('key' => 'book_price', 'value' => '"' . $bookprice . '"', 'compare' => 'LIKE') ) : null ;
//         $rating ? array_push($meta_query_array, array('key' => 'rating', 'value' => $rating, 'compare' => '>=') ) : null ;

//         // final meta_query
//         $query->set( 'meta_query', $meta_query_array );

//         // used to conditionally build the tax_query
//         // the tax_query is used for a custom taxonomy assigned to the post type
//         // i'm using the `'relation' => 'OR'` to make the search more broad
//         $tax_query_array = array('relation' => 'OR');

//         // conditionally add arrays to the tax_query based on values in the URL
//         // `movie_category` is the name of my custom taxonomy
//         $author ? array_push($tax_query_array, array('taxonomy' => 'author', 'field' => 'term_id', 'terms' => $author) ) : null ;

//         // final tax_query
//         $query->set( 'tax_query', $tax_query_array);
//     }
// }
// add_action( 'pre_get_posts', 'movie_archive' );