<!DOCTYPE html>
<html>
<head>
    <title>Form</title>
    <style type="text/css">
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }

        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }

        tr:nth-child(even) {
          background-color: #dddddd;
        }
    </style>
</head>
<body>
    <table style="width:100%">
      <tr>
        <th>No</th>
        <th>Book Name</th>
        <th>Price</th>
        <th>Author</th>
        <th>Publisher</th>
        <th>Rating</th>
      </tr>

    <?php
    // Get data from URL into variables
    $_name = $_GET['name'] != '' ? $_GET['name'] : '';
    $_author = $_GET['author'] != '' ? $_GET['author'] : '';
    $_publisher = $_GET['publisher'] != '' ? $_GET['publisher'] : '';
    $_rating = $_GET['rating'] != '' ? $_GET['rating'] : '';


    // print_r($_rating);

     // print_r($_publisher);
    // Start the Query
    $search_term = get_search_query();
    $args = array (
            'post_type' => 'book',
            'order' => 'ASC',
            'orderby' => 'title',
            'posts_per_page' => -1,
            'nopaging' => true,
            's' => $search_term
        );
    $args2 = array (
            'post_type' => 'book',
            'posts_per_page' => -1,
            'nopaging' => true,
            'meta_query' => array(
                 array(
                    'key' => 'rating',
                    'value' => $_rating,
                    'compare' => 'LIKE'
                 )
              )
        );

    $courses1 = get_posts($args);
    $courses2 = get_posts($args2);
    // print_r($courses2);
    $merged = array_merge($courses1, $courses2);

     $post_ids = array();
        foreach ($merged as $item) {
            $post_ids[] = $item->ID;
        }

        $unique = array_unique($post_ids);



    $posts = array(
            'post_type' => 'book',
            'order' => 'ASC',
            'orderby' => 'title',
            'post__in' => $unique,
            'posts_per_page' => -1
        );

    
    $book = new WP_Query($posts);

 

    if( $book->have_posts() ) :
             while( $book->have_posts() ): $book->the_post();?>
            <tr>
                <td><?php echo get_the_id();?></td>
                <td><a href="<?php echo get_permalink();?>"><?php the_title();?></a></td>
                <td><?php echo $_author;?></td>
                <td><?php echo $_publisher;?></td>
                <td></td>
                <td>5</td>
            </tr>
        <?php endwhile;
        wp_reset_postdata();
        else :
            _e( 'Sorry, nothing matched your search criteria', 'textdomain' );
    endif;?>
    </table>
</body>
</html>